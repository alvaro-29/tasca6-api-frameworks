// taskRoute.js - OP1-B1-NODE-05 - Frameworks - Fet per Álvaro Gómez Fernández

const express = require('express');
const router = express.Router();
const taskController = require('../controllers/taskController');

router.post('/tasks', taskController.createTask);  // Crear una tasca
router.get('/tasks', taskController.getTasks);  // Obtenir totes les tasques
router.get('/tasks/:id', taskController.getEspecificTask);  // Obtenir tasca específica
router.put('/tasks/:id', taskController.updateTask);  // Actualitzar una tasca
router.delete('/tasks/:id', taskController.deleteTask);  // Eliminar una tasca

module.exports = router;

// Fet per Álvaro Gómez Fernández