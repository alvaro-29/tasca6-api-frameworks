// app.js - OP1-B1-NODE-05 - Frameworks - Fet per Álvaro Gómez Fernández

const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors') ;

const app = express(); // Inicialitzar Express

// Middleware per gestionar CORS (Cross-Origin Resource Sharing)
app.use(cors());

// Middleware per analitzar JSON i formularis URL-encoded
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Ruta inicial de prova
app.get('/', (req, res) => {
    res.send({ message: 'Gestor de tasques en funcionament!'});
});

// Importar rutes
const taskRoutes = require('./routes/taskRoutes');
app.use('/api', taskRoutes);  // Afegir les rutes de tasques

module.exports = app;  // Exportar l'aplicació

// Fet per Álvaro Gómez Fernández