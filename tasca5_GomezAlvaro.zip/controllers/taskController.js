const Tasca = require('../models/Task');  // Importem el model Tasca

// Crear una nova tasca
exports.createTask = (req, res) => {

    const { titol, description, cost, hours_estimated, hours_real, image, completed, finished_at } = req.body;

    // Validacions bàsiques abans de crear la tasca
    if (!titol || cost === undefined || hours_estimated === undefined) {
        return res.status(400).send({ error: 'Falten camps obligatoris: títol, cost o hores estimades.' });
    } 

    if (titol.trim().length < 3 || titol.trim().length > 50) {
        return res.status(400).send({ error: 'El títol ha de tenir entre 3 i 50 caràcters.' });
    }

    if (description && description.trim().length > 500) {
        return res.status(400).send({ error: 'La descripció no pot superar els 500 caràcters.' });
    }

    if (cost < 0) {
        return res.status(400).send({ error: 'El cost no pot ser negatiu.' });
    }

    if (hours_estimated < 0) {
        return res.status(400).send({ error: 'Les hores estimades han de ser positives.' });
    }

    if (hours_real !== undefined && hours_real < 0) {
        return res.status(400).send({ error: 'Les hores reals no poden ser negatives.' });
    }

    if (image && !/^https?:\/\/[^\s]+$/.test(image)) {
        return res.status(400).send({ error: 'La URL de la imatge no és vàlida.' });
    }

    if (completed && !finished_at) {
        return res.status(400).send({ error: 'Si la tasca està completada, cal indicar la data de finalització.' });
    }

    // Creem la nova tasca amb les dades validades
    const tascaNova = new Tasca({
        titol,
        description,
        cost,
        hours_estimated,
        hours_real,
        image,
        completed,
        finished_at
    });

    // Guardem la tasca a la base de dades
    tascaNova.save()
        .then(tascaGuardada => {
            return res.status(201).send(tascaGuardada); // Retornem la tasca creada
        })
        .catch(err => {
            return res.status(400).send({ error: "No s'ha pogut crear la tasca", details: err.message });
        });
};

// Llistar totes les tasques
exports.getTasks = (req, res) => {

    Tasca.find()  // Obtenim totes les tasques
        .then(tasques => {
            return res.status(200).send(tasques);  // Retornem totes les tasques
        })
        .catch(err => {
            return res.status(500).send({ error: 'Error obtenint les tasques', details: err.message})
        })
};

// Mostrar una tasca específica per ID
exports.getEspecificTask = (req, res) => {

    Tasca.findById(req.params.id)
        .then(tasca => {
            if (!tasca) {
                return res.status(404).send({ error: "No s'ha trobat cap tasca amb aquest ID" });
            }
            res.status(200).send(tasca); // Retornem la tasca trobada
        })
        .catch(err => {
            res.status(400).send({ error: 'ID invàlid o error en la consulta', details: err.message });
        });

};

// Actualitzar una tasca específica
exports.updateTask = (req, res) => {

    // findByIdAndUpdate actualitza el document i retorna el document nou amb runValidators activat
    Tasca.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true })
        .then(tascaUpdated => {
            if (!tascaUpdated) {
                return res.status(404).send({ message: 'Tasca no trobada' });
            }
            res.status(200).send(tascaUpdated); // Retornem la tasca actualitzada
        })
        .catch(err => {
            res.status(400).send({ error: 'Error actualitzant la tasca', details: err.message });
        });
};

// Eliminar una tasca específica
exports.deleteTask = (req, res) => {

    Tasca.findByIdAndDelete(req.params.id) // Elimina la tasca per ID
        .then(tascaEliminada => {
            if (!tascaEliminada) {
                return res.status(404).send({ message: 'Tasca no trobada' });
            }
            res.status(200).send({ message: 'Tasca eliminada amb èxit', tasca: tascaEliminada });
        })
        .catch(err => {
            res.status(500).send({ error: 'Error eliminant la tasca', details: err.message });
        });
};

// Fet per Álvaro Gómez Fernández